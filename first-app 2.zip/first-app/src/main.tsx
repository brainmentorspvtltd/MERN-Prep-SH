// VDOM HandShake (Sync) DOM
// ReactDOM
import { createRoot } from "react-dom/client";
import App from "./App";

// dom
const rootDiv = document.querySelector('#root');
createRoot(rootDiv!).render(<App/>);