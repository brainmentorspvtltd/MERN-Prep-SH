

 const One = (props:{title:string, msg:string}) => {
  return (
   <>
   <h3>I am the One Component {props.title} {props.msg}</h3>
   </>
  )
}
export default One;
