// Root Component
// Component - Function (Prefer Arrow Function)
// Component - Small UI
import './App.css';
import React from 'react';
import One from './components/One';
const App = ()=>{
  const fruits  = ['Apple', 'Orange', 'Mango'];
  let isDisplay = true;
  let isLogin = false;
  const myStyle = {color:'red', backgroundColor:'yellow'};
  let  name:string = "Amit";
  //return  React.createElement('h1', null, 'Hello React with TS.....'), React.createElement('h2', null, 'Hi React with TS.....');
  return (<div><h1 style={myStyle}>Hello React with TS</h1>
  <h2 className='blue'>Hi React JS {name.toUpperCase()}</h2>
  {isDisplay && <p>Hello User</p>}
  {isLogin?<div><p>Welcome User</p><button>Logout</button></div>:<button>Login</button>}
  <ul>
  {fruits.map((fruit, index)=><li key = {index}>{fruit}</li>)}
  </ul>
  <One title="I am the Parent Data " msg="Hi One "/>
  </div>)
}
export default App;