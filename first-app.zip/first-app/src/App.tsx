// Root Component
// Component - Function (Prefer Arrow Function)
// Component - Small UI
import React from 'react';
const App = ()=>{
  //return  React.createElement('h1', null, 'Hello React with TS.....'), React.createElement('h2', null, 'Hi React with TS.....');
  return (<div><h1>Hello React with TS</h1><h2>Hi React JS</h2></div>)
}
export default App;