import { useEffect, useState } from "react"
import NewQuote from "../components/NewQuote"
import Quote from "../components/Quote"
import getNewQuote, { QuoteData } from "../services/api-client"

const QuoteApp = ()=>{
    const [quote , setQuote] = useState<QuoteData | null>(null);
    // Life Cycle of Component
    const getQuoteFromApi = async ()=>{
        const quote = await getNewQuote();
        setQuote(quote);
    }
    // Life Cycle Hook
    useEffect(()=>{
        getQuoteFromApi();
    },[]);

    return (<div>
        <Quote msg={quote?.quote} author={quote?.author}/>
        <NewQuote fn = {getQuoteFromApi}/>
    </div>)
}
export default QuoteApp;