import axios from "axios";
export type QuoteData = {
    quote:string;
    author:string;
    id:number;
}
const getNewQuote = async () :Promise<QuoteData>=>{
    const response = await axios.get(import.meta.env.VITE_QUOTE_URL);
    const quote:QuoteData = {id: response.data.id, quote: response.data.quote, author: response.data.author};
    return quote;
}
export default getNewQuote;

// //var a:number;
// var b:Array<string>;

// class A<T>{
//     data:T;
//     constructor(data:T){
//         this.data = data;
//     }
// }
// var a:A<number> = new A(10);