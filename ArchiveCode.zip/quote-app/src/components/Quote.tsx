const Quote = ({msg, author}:{msg?:string, author?:string})=>{
    return (<h1>{msg} - "{author}"</h1>)
}
export default Quote;