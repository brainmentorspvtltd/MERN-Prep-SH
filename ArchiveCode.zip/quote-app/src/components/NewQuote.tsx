import { MouseEventHandler } from "react";

const NewQuote = ({fn}:{fn : MouseEventHandler<HTMLButtonElement>})=>{
    return (<button onClick={fn}>New Quote</button>)
}
export default NewQuote;