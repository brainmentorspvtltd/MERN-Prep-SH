type MessageProps = {
    msg:string;
    val?:number | undefined;
}

export const Message = (props:MessageProps)=>{
    return (<h2>{props.msg} {props.val}</h2>);
}