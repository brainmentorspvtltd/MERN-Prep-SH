import { MouseEventHandler } from "react"

export const Button = ({val, fn, count}:{val:string, fn:MouseEventHandler<HTMLButtonElement>, count:number})=>{
   
    return (<><button onClick={fn}>{val}</button> <span>{count}</span></>)
}