import { MouseEventHandler } from "react"

export const Button =({fn}:{fn:MouseEventHandler<HTMLButtonElement>})=>{
    return (<button onClick={fn}>Color Change</button>)
}