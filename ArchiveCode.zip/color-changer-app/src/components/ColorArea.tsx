export const ColorArea = ({color}:{color:string})=>{
    const myStyle = {
        width:'200px',
        height:'200px',
        backgroundColor:color
    }
    return (<div style={myStyle}>

    </div>)
}