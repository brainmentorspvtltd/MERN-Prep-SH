export const generateRandomColor=()=>{
    let hexaColor = '#';
    const hexa = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'];
    for(let i = 1; i<=6; i++){
        const random = parseInt((Math.random() *15).toString());
        hexaColor = hexaColor + hexa[random];
    }
    return hexaColor;
}