import { useState } from "react"
import { Button } from "../components/Button"
import { ColorArea } from "../components/ColorArea"
import { generateRandomColor } from "../services/color-changer-logic";

export const ColorChangerApp = ()=>{
    const [color, setColor] = useState("#FFFFFF");
    const changeColor = ()=>{
        setColor(generateRandomColor());
    }
    return (<div>
        <h1>Color Changer App</h1>
        <ColorArea color={color}/>
        <Button fn = {changeColor}/>
    </div>)
}