import { useState } from "react";
import { Button } from "../components/Button"
import { Message } from "../components/Message"

export const CounterApp =()=>{
    // Hooks
    const [count, setCount] = useState(0);
   
    const plus = ()=>{
       setCount(count+1);
        // count++; 
        console.log('Plus is ', count);
    }
    const minus = ()=>{
        setCount(count-1);
        console.log('Minus is ', count);
    }
    return (<div>
        <Message msg="Counter App "/>
        <Message msg="Count is " val = {count}/>
        <Button val="+" fn={plus}  count = {count} /> &nbsp;
        <Button val="-" fn={minus} count = {count}/>
    </div>)
}