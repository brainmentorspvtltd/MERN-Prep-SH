import Todo from "./modules/todo/pages/Todo";

const App = ()=>{
  return (<>
    <Todo/>
  </>);
}
export default App;