import { Route, Routes } from "react-router-dom"
import Home from "../../modules/todo/components/Home"
import ToDoAddForm from "../../modules/todo/components/ToDoAddForm"
import List from "../../modules/todo/components/List"
import Edit from "../../modules/todo/components/Edit"
import About from "../../modules/todo/components/About"
import Todo from "../../modules/todo/pages/Todo"

const AppRoutes = ()=>{
    return (<Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/add" element={<ToDoAddForm/>}/>
        <Route path="/list" element={<List/>}/>
        <Route path="/edit" element={<Edit/>}/>
        <Route path="/about" element={<About/>}/>
    </Routes>)
}
export default AppRoutes;