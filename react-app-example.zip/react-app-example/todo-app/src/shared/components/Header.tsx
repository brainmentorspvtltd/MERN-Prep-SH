import { Link } from "react-router-dom";

const Header = ()=>{
    return (<div>
        <Link to="/">Home</Link> &nbsp;
        <Link to ="/add">Add Task</Link>&nbsp;
        <Link to ="/list">View All Task</Link>&nbsp;
        <Link to ="/edit">Edit Task</Link>&nbsp;
        <Link to ="/about">About us</Link>
    </div>)
}
export default Header;