import { create } from "zustand";

// Type
type ToDo = {
    name:string;
    desc:string;
}
// State + Operations
// Contract - What to do
interface ToDoState{
    todos:ToDo[], // State (Array of todo objects)
    add:(todo:ToDo)=>void; // Operation
    // remove, edit, search, sort
}

// {todos, name, length, photo}
const useToDoStore = create<ToDoState>((set)=>({
    todos:[],
    add:(todo:ToDo)=>set((state)=>({todos:[...state.todos, todo]}))
}))
export default useToDoStore;