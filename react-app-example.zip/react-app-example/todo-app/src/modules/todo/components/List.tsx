import useToDoStore from "../store/todo-store";

const List = ()=>{
    const {todos} = useToDoStore();
    console.log('All Todo ', todos);
    return (<h1>List {todos.length}</h1>)
}
export default List;