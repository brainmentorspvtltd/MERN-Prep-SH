const Home = ()=>{
    return (<div>
        <h1>To Do App</h1>
        <h3>Powered by Brain Mentors</h3>
    </div>)
}
export default Home;