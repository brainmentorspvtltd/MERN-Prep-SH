// Select elements
const grandparent = document.getElementById("grandparent");
const parent = document.getElementById("parent");
const child = document.getElementById("child");
const logContainer = document.getElementById("log");

// Utility function to log events
function logEvent(message) {
  const log = document.getElementById("log");
  const listItem = document.createElement("li");
  listItem.textContent = message;
  log.appendChild(listItem);
}

// Add event listeners
grandparent.addEventListener(
  "click",
  (event) => {
    logEvent("Grandparent: Capturing Phase");
  },
  true // Capturing phase
);

grandparent.addEventListener("click", (event) => {
  logEvent("Grandparent: Bubbling Phase");
});

parent.addEventListener(
  "click",
  (event) => {
    logEvent("Parent: Capturing Phase");
  },
  true // Capturing phase
);

parent.addEventListener("click", (event) => {
  logEvent("Parent: Bubbling Phase");
});

child.addEventListener(
  "click",
  (event) => {
    logEvent("Child: Capturing Phase");
  },
  true // Capturing phase
);

child.addEventListener("click", (event) => {
  logEvent("Child: Bubbling Phase");

  // Stop propagation if uncommented
  // event.stopPropagation();
});

// Reset log button for convenience
const resetLogButton = document.createElement("button");
resetLogButton.textContent = "Clear Log";
resetLogButton.style.marginTop = "10px";
resetLogButton.addEventListener("click", () => {
  logContainer.querySelector("#log").innerHTML = "";
});
logContainer.appendChild(resetLogButton);