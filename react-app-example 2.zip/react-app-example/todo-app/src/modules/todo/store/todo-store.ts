import { create } from "zustand";

// Type
type ToDo = {
    id:number;
    name:string;
    desc:string;
}
// State + Operations
// Contract - What to do
interface ToDoState{
    todos:ToDo[], // State (Array of todo objects)
    add:(todo:ToDo)=>void; // Operation
    remove:(id:number)=>void;
    // remove, edit, search, sort
}

// {todos, name, length, photo}
const useToDoStore = create<ToDoState>((set)=>({
    todos:[],
    add:(todo:ToDo)=>set((state)=>({todos:[...state.todos, todo]})),
    remove:(id:number)=>set((state)=>({todos:state.todos.
        filter(todo=>todo.id !=id)}))
}))
export default useToDoStore;