import { useForm } from "react-hook-form";
import useToDoStore from "../store/todo-store";

type ToDoFormFields = {
    id:number;
    name:string;
    desc:string;
}
const ToDoAddForm = ()=>{
    const {add} = useToDoStore();
    const {register, handleSubmit, formState:{errors}, reset}= useForm<ToDoFormFields>();
    const onSubmitToDo = (obj:ToDoFormFields)=>{
        console.log('Form Data is ', obj);
        obj.id = Date.now();
        alert("Form Submit");
        add(obj);
        reset();
    }
    return (<div>
            <h1>To Do Add Form</h1>
            <form onSubmit={handleSubmit(onSubmitToDo)}>
                <label>Task Name</label>
                <input {...register('name',{required:'Task name is Required', 
                maxLength:50})}  type='text' placeholder="Type Name Here"/>
                 {errors && errors.name && <span style={{color:'red'}}>{errors.name.message}</span> }
                <br />
                <label htmlFor="">Task Desc</label>
                <textarea {...register('desc', {required:'Task Desc is required', maxLength:200})} 
                placeholder="Type Desc Here" cols={30} rows={5}></textarea>
                {errors && errors.desc && <span  style={{color:'red'}}>{errors.desc.message}</span> }
                <br />
                <button>Add New Task</button>
            </form>
    </div>)
}
export default ToDoAddForm;