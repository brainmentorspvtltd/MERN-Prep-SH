import useToDoStore from "../store/todo-store";
import './List.css';
const List = ()=>{
    const {todos, remove} = useToDoStore();
    console.log('All Todo ', todos);
    const removeCurrentRecord = (id:number)=>{
        console.log('Record to be remove ', id);
        remove(id);
    }
   // return (<h1>List {todos.length}</h1>)
   return (<>
    <h1>Total Records {todos.length}</h1>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Desc</th>
                <th>Operations</th>
            </tr>
        </thead>
        <tbody>
            {todos.map((todo, index)=><tr key={index}><td>{todo.id}</td><td>{todo.name}</td><td>{todo.desc}</td>
            <td><i onClick={()=>{
                removeCurrentRecord(todo.id);
            }} className="fa-solid fa-trash"></i></td> </tr>)}
        </tbody>
    </table>
   </>)
}
export default List;