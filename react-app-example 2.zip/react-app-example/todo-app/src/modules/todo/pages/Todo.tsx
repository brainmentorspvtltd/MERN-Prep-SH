import { BrowserRouter, Outlet } from "react-router-dom";
import Header from "../../../shared/components/Header";
import AppRoutes from "../../../shared/routes/AppRoutes";

const Todo = ()=>{
    return (<div>
        <BrowserRouter>
        <Header/>
        <hr/>
        <AppRoutes/>
        
        
        </BrowserRouter>
    </div>); // this is main page which contains the navigation
}
export default Todo;